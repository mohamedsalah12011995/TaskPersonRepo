﻿using AutoMapper;
using TaskPersonRepo.Core.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using TaskPersonRepo.DAL;

namespace TaskPersonRepo.Core.MappingProfils
{
    public class AddressProfile : Profile
    {
        public AddressProfile()
        {
            CreateMap<Address, AddressDto>();
            CreateMap<AddressDto, Address>();

        }
    }
}
