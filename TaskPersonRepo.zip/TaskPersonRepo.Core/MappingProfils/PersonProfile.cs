﻿using AutoMapper;
using TaskPersonRepo.Core.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using TaskPersonRepo.DAL;

namespace TaskPersonRepo.Core.MappingProfils
{
    public class PersonProfile : Profile
    {
        public PersonProfile()
        {
            CreateMap<Person, PersonObjDto>();
            CreateMap<PersonObjDto, Person>();

            CreateMap<Person, PersonDto>()
              .ForPath(dest => dest.AddressName, opt => opt.MapFrom(src => src.Address != null ? src.Address.Name : ""));
            CreateMap<PersonDto, Person>();

        }
    }
}
