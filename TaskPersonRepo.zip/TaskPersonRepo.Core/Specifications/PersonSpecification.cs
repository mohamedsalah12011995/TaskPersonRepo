﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using TaskPersonRepo.Core;
using TaskPersonRepo.Core.Dto;
using TaskPersonRepo.DAL;

namespace TaskPersonRepo.Core.Specifications
{

    public sealed class PersonSpecification : Specification<Person>
    {
        private readonly PersonDto _caseObj;

        public PersonSpecification(PersonDto caseObj)
        {
            _caseObj = caseObj;
        }

        public override Expression<Func<Person, bool>> ToExpression()
        {
            return FilteredCase => (
            (string.IsNullOrEmpty(_caseObj.Name) || (FilteredCase.Name).Contains(_caseObj.Name)) &&
            (FilteredCase.Age == _caseObj.Age || _caseObj.Age == 0)
          
            );
        }
    }
}













