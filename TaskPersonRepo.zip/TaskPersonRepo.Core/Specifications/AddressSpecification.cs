﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using TaskPersonRepo.Core;
using TaskPersonRepo.Core.Dto;
using TaskPersonRepo.DAL;

namespace TaskPersonRepo.Core.Specifications
{

    public sealed class AddressSpecification : Specification<Address>
    {
        private readonly AddressDto _caseObj;

        public AddressSpecification(AddressDto caseObj)
        {
            _caseObj = caseObj;
        }

        public override Expression<Func<Address, bool>> ToExpression()
        {
            return FilteredCase => (
            (string.IsNullOrEmpty(_caseObj.name) || (FilteredCase.Name).Contains(_caseObj.name))
          
            );
        }
    }
}













