﻿using TaskPersonRepo.Core.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskPersonRepo.DAL;

namespace TaskPersonRepo.Core.Interfaces
{
    public interface IPersonRepository : IBaseRepository<Person>
    {
        Task<List<PersonDto>> GetAllPersons();
        Task<Person> AddEntity(PersonObjDto dto);
       Task<Person?> EditEntity(PersonObjDto dto);
       Task<bool> DeleteClinic(int id);

    }
}