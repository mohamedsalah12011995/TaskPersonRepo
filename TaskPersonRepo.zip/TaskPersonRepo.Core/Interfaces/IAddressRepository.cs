﻿using TaskPersonRepo.Core.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskPersonRepo.DAL;

namespace TaskPersonRepo.Core.Interfaces
{
    public interface IAddressRepository : IBaseRepository<Address>
    {
        Task<List<AddressDto>> GetAllAddresses();

        Task<Address> AddEntity(AddressDto dto);
        Task<Address?> EditEntity(AddressDto dto);
        Task<bool> DeleteEntity(int id);
    }
}