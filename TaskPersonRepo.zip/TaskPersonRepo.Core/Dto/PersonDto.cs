﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskPersonRepo.Core.Dto
{
   public class PersonObjDto
    {
        public int id { get; set; }
        public string name { get; set; }
        public double age { get; set; }
        public int addressId { get; set; }
    }

    public class PersonDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Age { get; set; }
        public string AddressName { get; set; }

    }
}
