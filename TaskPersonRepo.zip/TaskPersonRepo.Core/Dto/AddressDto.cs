﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskPersonRepo.Core.Dto
{
   public class AddressDto
    {
        public int id { get; set; }
        public string name { get; set; }

    }

}
