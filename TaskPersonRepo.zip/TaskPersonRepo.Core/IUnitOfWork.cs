﻿using TaskPersonRepo.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskPersonRepo.DAL;

namespace TaskPersonRepo.Core
{
    public interface IUnitOfWork : IDisposable
    {
        IAddressRepository Addresses { get; }
        IPersonRepository Person { get; }

        int Complete();
    }
}