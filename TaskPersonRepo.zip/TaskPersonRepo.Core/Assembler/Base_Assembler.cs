﻿using AutoMapper;
using AutoMapper.Configuration;
using TaskPersonRepo.Core.MappingProfils;
using System;
using System.Collections.Generic;
using System.Text;

namespace TaskPersonRepo.Core.Assembler
{
    public class Base_Assembler
    {

        private static readonly object _padlock = new object();

        private static bool _isInit = false;

        public IMapper BaseMapper;


        public Base_Assembler()
        {
            lock (_padlock)
            {
                InitMapper();
            }
        }

        private void InitMapper()
        {
            var cfg = new MapperConfigurationExpression();

            cfg.AddProfile<PersonProfile>();
            cfg.AddProfile<AddressProfile>();




            var mapperConfig = new MapperConfiguration(cfg);
            BaseMapper = new Mapper(mapperConfig);


        }
    }
}

    

