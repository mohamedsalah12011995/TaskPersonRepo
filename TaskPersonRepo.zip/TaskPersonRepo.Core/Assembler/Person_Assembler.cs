﻿using TaskPersonRepo.Core.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using TaskPersonRepo.DAL;

namespace TaskPersonRepo.Core.Assembler
{
    public class Person_Assembler : Base_Assembler
    {
        public Person WriteDal(PersonObjDto data)
        {
            return BaseMapper.Map<Person>(data);
        }

        public List<Person> WriteListDal(IEnumerable<PersonDto> data)
        {
            return BaseMapper.Map<List<Person>>(data);
        }
        public List<PersonDto> WriteListDto(IEnumerable<Person> data)
        {
            return BaseMapper.Map<List<PersonDto>>(data);
        }
        public PersonDto WriteDto(Person data)
        {
            return BaseMapper.Map<PersonDto>(data);

        }
    }
}
