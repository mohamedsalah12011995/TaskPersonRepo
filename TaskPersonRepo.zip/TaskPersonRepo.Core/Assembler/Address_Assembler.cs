﻿using TaskPersonRepo.Core.Dto;
using System;
using System.Collections.Generic;
using System.Text;
using TaskPersonRepo.DAL;

namespace TaskPersonRepo.Core.Assembler
{
    public class Address_Assembler : Base_Assembler
    {
        public Address WriteDal(AddressDto data)
        {
            return BaseMapper.Map<Address>(data);
        }

        public List<Address> WriteListDal(IEnumerable<AddressDto> data)
        {
            return BaseMapper.Map<List<Address>>(data);
        }
        public List<AddressDto> WriteListDto(IEnumerable<Address> data)
        {
            return BaseMapper.Map<List<AddressDto>>(data);
        }
        public AddressDto WriteDto(Address data)
        {
            return BaseMapper.Map<AddressDto>(data);

        }
    }
}
