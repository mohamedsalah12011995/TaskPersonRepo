﻿using TaskPersonRepo.Core;
using TaskPersonRepo.Core.Interfaces;
using TaskPersonRepo.EF.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskPersonRepo.Core.Assembler;
using TaskPersonRepo.DAL;

namespace TaskPersonRepo.EF
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly TaskPersonRepoDbContext _context;
        private readonly Person_Assembler _Person_Assembler;

        public IPersonRepository Person { get; private set; }
        public IAddressRepository Addresses { get; private set; }



        public UnitOfWork(TaskPersonRepoDbContext context)
        {
            _context = context;

            Person = new PersonRepository(_context);
            Addresses = new AddressRepository(_context);
        }

        public int Complete()
        {
            return _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}