﻿using TaskPersonRepo.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskPersonRepo.Core.Dto;
using TaskPersonRepo.Core.Assembler;
using TaskPersonRepo.DAL;
using Microsoft.EntityFrameworkCore;

namespace TaskPersonRepo.EF.Repositories
{
    public class PersonRepository : BaseRepository<Person>, IPersonRepository
    {
        private readonly TaskPersonRepoDbContext _context;
        private readonly Person_Assembler _Person_Assembler;

        public PersonRepository(TaskPersonRepoDbContext context) : base(context)
        {
            _context = context;
            _Person_Assembler = new Person_Assembler();
        }

        public async Task<Person> AddEntity(PersonObjDto dto)
        {
            var entity = _Person_Assembler.WriteDal(dto);
            await AddAsync(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        public async Task<bool> DeleteClinic(int id)
        {
            var Exite = FindAsync(x => x.Id == id).Result;
            if (Exite != null)
            {
                Delete(Exite);
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<Person?> EditEntity(PersonObjDto dto)
        {
            try
            {
                var Exite = FindAsync(x => x.Id == dto.id).Result;
                if (Exite != null)
                {
                    var entity = _Person_Assembler.WriteDal(dto);
                    await UpdateAsync(entity, Exite);
                    await _context.SaveChangesAsync();
                    return entity;
                }
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }

        }


        public async Task<List<PersonDto>> GetAllPersons()
        {

            var _Person = await FindAllAsync(b => b.AddressId != 0, new[] { "Address" });
            var _PersonDto = _Person_Assembler.WriteListDto(_Person.ToList());
            return _PersonDto;
        }

    }
}