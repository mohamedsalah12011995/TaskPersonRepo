﻿using TaskPersonRepo.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskPersonRepo.Core.Dto;
using TaskPersonRepo.Core.Assembler;
using TaskPersonRepo.DAL;

namespace TaskPersonRepo.EF.Repositories
{
    public class AddressRepository : BaseRepository<Address>, IAddressRepository
    {
        private readonly TaskPersonRepoDbContext _context;
        private readonly Address_Assembler _Address_Assembler;

        public AddressRepository(TaskPersonRepoDbContext context) : base(context)
        {
            _context = context;
            _Address_Assembler = new Address_Assembler();
        }

        public async Task<Address> AddEntity(AddressDto dto)
        {
            var entity = _Address_Assembler.WriteDal(dto);
            await AddAsync(entity);
            await _context.SaveChangesAsync();
            return entity;
        }

        public async Task<Address?> EditEntity(AddressDto dto)
        {
            try
            {
                var Exite = FindAsync(x => x.Id == dto.id).Result;
                if (Exite != null)
                {
                    var entity = _Address_Assembler.WriteDal(dto);
                    await UpdateAsync(entity, Exite);
                    await _context.SaveChangesAsync();
                    return entity;
                }
                return null;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public async Task<bool> DeleteEntity(int id)
        {
            var Exite = FindAsync(x => x.Id == id).Result;
            if (Exite != null)
            {
                Delete(Exite);
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task<List<AddressDto>> GetAllAddresses()
        {
            var _Address = await GetAllAsync();
            var __AddressDto = _Address_Assembler.WriteListDto(_Address.ToList());
            return __AddressDto;
        }
    }
}