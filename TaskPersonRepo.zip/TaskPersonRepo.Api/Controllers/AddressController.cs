﻿using TaskPersonRepo.Core;
using TaskPersonRepo.Core.Dto;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TaskPersonRepo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddressController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;

        public AddressController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IActionResult GetById()
        {
            return Ok(_unitOfWork.Addresses.GetById(1));
        }

        [HttpGet("GetAll")]
        public IActionResult GetAll()
        {
            return Ok(_unitOfWork.Addresses.GetAllAddresses());
        }

        [HttpGet("GetByName")]
        public IActionResult GetByName()
        {
            return Ok(_unitOfWork.Addresses.Find(b => b.Name == "New Address", new[] { "Address" }));
        }

        [HttpGet("GetAllWithAddress")]
        public IActionResult GetAllWithAddress()
        {
            return Ok(_unitOfWork.Addresses.FindAll(b => b.Name.Contains("New Address"), new[] { "Address" }));
        }


        [HttpPost("AddAddressAsync")]
        public IActionResult AddAddressAsync(AddressDto dto)
        {
            var _Address = _unitOfWork.Addresses.AddEntity(dto);
            return Ok(_Address);
        }

        [HttpPut("EditAddressAsync")]
        public IActionResult EditAddressAsync(AddressDto dto)
        {
            var _Address = _unitOfWork.Addresses.EditEntity(dto);
            return Ok(_Address);
        }

        [HttpDelete("deleteAddressAsync")]
        public async Task<IActionResult> DeleteAddressAsync(int id)
        {
            var _Clinice = await _unitOfWork.Addresses.DeleteEntity(id);
            return Ok(_Clinice);
        }
    }
}