﻿using TaskPersonRepo.Core;
using TaskPersonRepo.Core.Dto;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TaskPersonRepo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;

        public PersonController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet]
        public IActionResult GetById()
        {
            return Ok(_unitOfWork.Person.GetById(1));
        }

        [HttpGet("GetAllPersons")]
        public IActionResult GetAll()
        {
            return Ok(_unitOfWork.Person.GetAllPersons());
        }

        [HttpGet("GetByName")]
        public IActionResult GetByName()
        {
            return Ok(_unitOfWork.Person.Find(b => b.Name == "New Person", new[] { "Person" }));
        }

        [HttpGet("GetAllWithPerson")]
        public IActionResult GetAllWithPerson()
        {
            return Ok(_unitOfWork.Person.FindAll(b => b.Name.Contains("New Person"), new[] { "Person" }));
        }


        [HttpPost("AddPersonAsync")]
        public IActionResult AddOne(PersonObjDto dto)
        {
            var _Person = _unitOfWork.Person.AddEntity(dto);
            return Ok(_Person);
        }

        [HttpPut("EditPersonAsync")]
        public IActionResult Edit(PersonObjDto dto)
        {
            var _Person = _unitOfWork.Person.EditEntity(dto);
            return Ok(_Person);
        }

        [HttpDelete("deletePerson")]
        public async Task<IActionResult> DeleteClinic(int id)
        {
            var _Clinice = await _unitOfWork.Person.DeleteClinic(id);
            return Ok(_Clinice);
        }
    }
}